package test;

public class Mul extends Arithmetic{

	@Override
	int calculation(int num1, int num2) {
		num3=num1*num2;
		return num3;
		
	}

}
