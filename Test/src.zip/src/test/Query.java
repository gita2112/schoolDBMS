package test;

public class Query {

}
